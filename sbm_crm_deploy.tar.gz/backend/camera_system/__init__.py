"""Computer vision and camera analytics system."""

from .traffic_monitor import TrafficMonitor

__all__ = [
    "TrafficMonitor"
]